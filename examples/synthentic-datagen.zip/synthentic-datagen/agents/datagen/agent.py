"""Synthetic data generator agent that writes and executes code to generate datasets."""

import rayai
from pydantic_ai import Agent
from rayai.sandbox import Sandbox

# Dockerfile with data science packages pre-installed
DOCKERFILE = """
FROM python:3.12-slim
RUN pip install --no-cache-dir pandas numpy faker scikit-learn
"""

# Create sandbox with pre-installed packages
sandbox = Sandbox(dockerfile=DOCKERFILE, timeout=120)

SYSTEM_PROMPT = """You are a synthetic data generator agent. Your job is to generate realistic synthetic datasets based on user requirements.

You have access to a Python sandbox with pandas, numpy, faker, and scikit-learn pre-installed.

When generating data:
1. Understand the user's requirements (columns, data types, relationships, constraints)
2. Write Python code to generate the synthetic data using appropriate libraries
3. Save the generated dataset to /tmp/output.csv (or other formats as requested)
4. Print a summary of the generated data (shape, columns, sample rows)

Tips:
- Use faker for realistic names, addresses, emails, etc.
- Use numpy for numerical distributions
- Use pandas for data manipulation and export
- Consider correlations between columns when relevant
- Add realistic noise and variation to make data look authentic

Always save the final dataset to a file in /tmp/ and confirm the file was created."""


def make_agent():
    """Create and configure the synthetic data generator agent."""
    return Agent(
        "openai:gpt-4o",
        system_prompt=SYSTEM_PROMPT,
        tools=[sandbox.run_code, sandbox.bash],
    )


# Serve the agent
rayai.serve(make_agent, name="datagen", num_cpus=1, memory="2GB")
